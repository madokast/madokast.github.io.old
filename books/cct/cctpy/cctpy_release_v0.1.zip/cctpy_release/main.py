from cctpy import Plot3

Plot3.__logo__()
